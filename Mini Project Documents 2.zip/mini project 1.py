import itertools
import json

# Define the teams
teams = [
    {"name": "Team1", "town": "Town1", "stadium": "Stadium1"},
    {"name": "Team2", "town": "Town2", "stadium": "Stadium2"},
    # Add more teams here...
]

# Generate all possible matches
matches = list(itertools.combinations(teams, 2))

# Sort matches so that teams from the same town play each other last
matches.sort(key=lambda x: x[0]["town"] == x[1]["town"])

# Split matches into weekends
weekends = [matches[i:i+2] for i in range(0, len(matches), 2)]

# Generate fixtures
fixtures = []
for i, weekend in enumerate(weekends, start=1):
    for match in weekend:
        fixtures.append({
            "weekend": f"Weekend #{i}",
            "leg": 1,
            "match": f"{match[0]['name']} vs {match[1]['name']}",
            "stadium": match[0]["stadium"],
            "town": match[0]["town"],
        })
        fixtures.append({
            "weekend": f"Weekend #{i}",
            "leg": 2,
            "match": f"{match[1]['name']} vs {match[0]['name']}",
            "stadium": match[1]["stadium"],
            "town": match[1]["town"],
        })

# Save fixtures to a JSON file
with open("fixtures.json", "w") as f:
    json.dump(fixtures, f, indent=4)

# Print fixtures
for fixture in fixtures:
    print(f"Weekend: {fixture['weekend']}, Match: {fixture['match']}, Stadium: {fixture['stadium']}, Town: {fixture['town']}, Leg: {fixture['leg']}")