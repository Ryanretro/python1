import pandas as pd

# Define the teams and their local towns
teams = ["CKlein Stars", "Dolpins FC", "Wolves FC", "Sea Horses FC", "Lions FC", "Rhinos FC", "Buffaloes FC", "Eagles FC", "Hawks FC", "Cheetahs FC"]
local_towns = ["Cape Town", "Durban", "Johannesburg", "Port Elizabeth", "Pretoria", "Bloemfontein", "East London", "Nelspruit", "Polokwane", "Rustenburg"]

# Create a DataFrame to store the fixtures
fixtures = pd.DataFrame(columns=["Home Team", "Away Team", "Local Town", "Stadium", "Leg", "Weekend"])

# Function to generate fixtures for a given team
def generate_fixtures_for_team(team, other_teams):
    # Shuffle the other teams list
    other_teams = list(other_teams)
    random.shuffle(other_teams)

    # Split the other teams into two groups
    group1 = other_teams[:len(other_teams) // 2]
    group2 = other_teams[len(other_teams) // 2:]

    # Play each team in group1 once at home and once away
    for other_team in group1:
        fixtures.loc[len(fixtures)] = [team, other_team, local_towns[teams.index(team)], "Home Stadium", 1, weekend_counter]
        weekend_counter += 1

        fixtures.loc[len(fixtures)] = [other_team, team, local_towns[teams.index(other_team)], "Away Stadium", 2, weekend_counter]
        weekend_counter += 1

    # Play each team in group2 twice at home and twice away
    for other_team in group2:
        fixtures.loc[len(fixtures)] = [team, other_team, local_towns[teams.index(team)], "Home Stadium", 1, weekend_counter]
        weekend_counter += 1

        fixtures.loc[len(fixtures)] = [other_team, team, local_towns[teams.index(other_team)], "Away Stadium", 2, weekend_counter]
        weekend_counter += 1

        fixtures.loc[len(fixtures)] = [team, other_team, local_towns[teams.index(team)], "Home Stadium", 3, weekend_counter]
        weekend_counter += 1

        fixtures.loc[len(fixtures)] = [other_team, team, local_towns[teams.index(other_team)], "Away Stadium", 4, weekend_counter]
        weekend_counter += 1

# Generate fixtures for each team
weekend_counter = 1
for team in teams:
    other_teams = list(teams)
    other_teams.remove(team)

    generate_fixtures_for_team(team, other_teams)

# Save the fixtures to a CSV file
fixtures.to_csv("fixtures.csv", index=False)

# Print the fixtures to the screen
print(fixtures)